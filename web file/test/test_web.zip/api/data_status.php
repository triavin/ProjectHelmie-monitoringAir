<?php
//SET HEADER
header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Headers: Origin, Content-Type, Authorization, Accept, X-Requested-with, x-xsrf-token");
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Allow-Methods: PUT, GET, POST, DELETE, OPTIONS");
header("Content-Type: application/json; charset=utf-8");

//Config Database
include('config.php');

$METHOD = $_SERVER['REQUEST_METHOD'];


if ($METHOD === 'GET') {

    // EKSEKUSI QUERY
    $query = mysqli_query($koneksi, "SELECT * from monitoring ORDER BY time DESC LIMIT 1");


    if ($query) { // JIKA QUERY BERHASIL DIEKSEKUSI

        $data = [];
        while ($row = mysqli_fetch_assoc($query)) {
            $data[] = $row;
        }

        echo json_encode(array(
            "result" => "success",
            "data" => $data
        ));
    } else { // JIKA QUERY GAGAL DIEKSEKUSI

        echo json_encode(array(
            "result" => "error",
            "message" => "Gagal mengambil data"
        ));
    }
}