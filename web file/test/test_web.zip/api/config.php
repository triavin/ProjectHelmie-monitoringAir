<?php
$hostname = "localhost";
$username = "id20397677_root";
$pass = "md0Y8%Ua8/vA8b$*";
$db = "id20397677_monitoringbanjir";

// Koneksi dengan database
$koneksi = mysqli_connect($hostname, $username, $pass, $db);
// periksa koneksi database

if (!$koneksi) {
 echo "Gagal Terhubung pada MySQL: " . $mysql_connect_error();
 exit();
}
else{
    // echo "Berhasil Terhubung";
}

?>