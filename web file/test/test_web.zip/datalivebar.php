<?php
    include_once 'config.php';
    
    $sql = mysqli_query($koneksi, "select * from monitoring ORDER BY time DESC LIMIT 1");
    $row = mysqli_fetch_array($sql);
    
    return $row["ketinggian"];
    
?>