<!DOCTYPE html>
<html lang="en" class="h-100">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css">

    <script src="jquery/jquery.min.js"></script>

    <title>Document</title>

    <script>
        $(document).ready(function () {
            setInterval(function () {
                $("#data").load("datahistory.php");
            }, 1000);
        })
    </script>
</head>

<body class="h-100 text-center text-dark bg-light">

    <nav class="navbar navbar-expand-lg navbar-dark fixed-top">
        <div class="container-fluid">
            <a href="/websensor/" class="navbar-brand">
                <h2>
                    Monitoring Suhu dan PH
                </h2>
            </a>
        </div>
        <div class="container"></div>
        <a href="/websensor/" class="navbar-brand">Home</a>
        <a href="monitoring.php" class="navbar-brand">Monitoring</a>
    </nav>

    <div class="cover-container d-flex w-100 h-100 p-3 mx-auto flex-column">
        <main class="my-auto">
            <table class="table table-striped table-dar">
                <thead>
                    <tr>
                        <th scope="col">no</th>
                        <th scope="col">Data Suhu</th>
                        <th scope="col">Dara pH</th>
                        <th scope="col">Time</th>
                    </tr>
                </thead>
                <tbody id="data">

                </tbody>
            </table>
        </main>

        <footer class="mt-auto mx-auto">
            <p>Aldi Triavin Dwi Putra (1811501481)</p>
        </footer>
    </div>

</body>

</html>

