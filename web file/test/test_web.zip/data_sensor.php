<?php

include_once 'sensor.php';

$app = new Sensor();
$app->query_string = $_SERVER['QUERY_STRING'];

if ($app->is_url_query('ketinggian') && $app->is_url_query('status')) {
 $ketinggian = $app->get_url_query_value('ketinggian');
 $status = $app->get_url_query_value('status');
 echo var_dump($status);
 $app->create_data($ketinggian, $status);
}
else{
    echo "link yang dimasukan salah";
}

?>
